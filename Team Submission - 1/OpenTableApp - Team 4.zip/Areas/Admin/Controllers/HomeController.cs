using Microsoft.AspNetCore.Mvc;

namespace OpenTable.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("[area]/[controller]")]
    public class HomeController : Controller
    {

        [Route("")]
        [Route("Index")]
        public IActionResult Index()
        {
            return View();
        }
    }
}
