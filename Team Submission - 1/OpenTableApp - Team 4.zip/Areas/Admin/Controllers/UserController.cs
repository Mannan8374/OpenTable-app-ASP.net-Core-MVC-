using Microsoft.AspNetCore.Mvc;

namespace OpenTable.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("[area]/[controller]")]
    public class UserController : Controller
    {
        [Route("List")]
        public IActionResult List()
        {
            return View();
        }

        [Route("Add")]
        public IActionResult Add()
        {
            return View();
        }

        [Route("Update/{id}")]
        public IActionResult Update(int id)
        {
            return View();
        }

        [Route("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            return View();
        }
    }
}
